package com.example.article_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArticleMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
