// UserRole.java
package com.appointments.appointmentservice.Entities;

public enum UserRole {
    PATIENT,
    DOCTOR
}