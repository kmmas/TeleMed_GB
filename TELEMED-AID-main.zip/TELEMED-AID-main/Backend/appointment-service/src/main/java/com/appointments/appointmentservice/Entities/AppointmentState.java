package com.appointments.appointmentservice.Entities;

public enum AppointmentState {
    PENDING,
    COMPLETED;
}
