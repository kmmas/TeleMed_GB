package com.example.notification_service.model;

public enum NotificationType {
    PRIVATE,
    ALL_DOCTORS,
    ALL_PATIENTS
}