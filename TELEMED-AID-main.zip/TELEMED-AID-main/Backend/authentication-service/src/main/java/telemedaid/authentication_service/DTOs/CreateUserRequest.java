package telemedaid.authentication_service.DTOs;

public interface CreateUserRequest {
}
