package telemedaid.authentication_service.Entities;

public enum Role {
    PATIENT,
    DOCTOR
}